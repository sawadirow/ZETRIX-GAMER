import type { TempEmail, EmailMessage } from '@/types/email';

const STORAGE_KEYS = {
  EMAIL: 'ghostmail_email',
  MESSAGES: 'ghostmail_messages',
  FAVORITES: 'ghostmail_favorites',
  API_KEY: 'ghostmail_api_key',
  USER: 'ghostmail_user',
  ACCOUNTS: 'ghostmail_accounts',
  USERS_DB: 'ghostmail_users_db',
  CURRENT_USER: 'ghostmail_current_user',
};

interface UserAccount {
  id: string;
  nickname: string;
  email: string;
  password: string;
  apiKey: string;
  createdAt: number;
  lastLogin: number;
}

export const storage = {
  // New Multi-User System
  registerUser(nickname: string, email: string, password: string, apiKey: string = ''): UserAccount {
    const usersDb = this.getAllUsers();
    
    // Check if email already exists
    const existing = usersDb.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      throw new Error('Email already registered');
    }

    // Create new user
    const newUser: UserAccount = {
      id: `user_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
      nickname,
      email,
      password,
      apiKey,
      createdAt: Date.now(),
      lastLogin: Date.now(),
    };

    usersDb.push(newUser);
    localStorage.setItem(STORAGE_KEYS.USERS_DB, JSON.stringify(usersDb));
    this.setCurrentUser(newUser);
    return newUser;
  },

  loginUser(email: string, password: string): UserAccount | null {
    const usersDb = this.getAllUsers();
    const user = usersDb.find(
      u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );

    if (user) {
      user.lastLogin = Date.now();
      localStorage.setItem(STORAGE_KEYS.USERS_DB, JSON.stringify(usersDb));
      this.setCurrentUser(user);
      return user;
    }

    return null;
  },

  updateUserApiKey(userId: string, apiKey: string): boolean {
    const usersDb = this.getAllUsers();
    const user = usersDb.find(u => u.id === userId);
    
    if (user) {
      user.apiKey = apiKey;
      localStorage.setItem(STORAGE_KEYS.USERS_DB, JSON.stringify(usersDb));
      
      // Update current user if it's the same
      const currentUser = this.getCurrentUser();
      if (currentUser && currentUser.id === userId) {
        currentUser.apiKey = apiKey;
        this.setCurrentUser(currentUser);
      }
      
      return true;
    }
    
    return false;
  },

  getAllUsers(): UserAccount[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.USERS_DB);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  },

  setCurrentUser(user: UserAccount): void {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    // Also set legacy keys for compatibility
    this.saveUser({ nickname: user.nickname, id: user.id });
    this.saveApiKey(user.apiKey);
  },

  getCurrentUser(): UserAccount | null {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  },

  logoutCurrentUser(): void {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    // Keep users DB intact, only clear current session
  },

  // Legacy compatibility methods
  saveApiKey(key: string): void {
    localStorage.setItem(STORAGE_KEYS.API_KEY, key);
  },

  getApiKey(): string | null {
    return localStorage.getItem(STORAGE_KEYS.API_KEY);
  },

  saveUser(user: { nickname: string; id: string }): void {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  },

  getUser(): { nickname: string; id: string } | null {
    const raw = localStorage.getItem(STORAGE_KEYS.USER);
    return raw ? JSON.parse(raw) : null;
  },

  saveTikTokAccounts(accounts: any[]): void {
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
  },

  getTikTokAccounts(): any[] {
    const raw = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
    return raw ? JSON.parse(raw) : [];
  },
  saveEmail(email: TempEmail): void {
    try {
      localStorage.setItem(STORAGE_KEYS.EMAIL, JSON.stringify(email));
    } catch (e) {
      console.error('[GhostMail] Failed to save email:', e);
    }
  },

  loadEmail(): TempEmail | null {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.EMAIL);
      if (!raw) return null;
      const email = JSON.parse(raw) as TempEmail;
      if (Date.now() > email.expiresAt) {
        this.clearEmail();
        return null;
      }
      return email;
    } catch {
      return null;
    }
  },

  clearEmail(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.EMAIL);
      localStorage.removeItem(STORAGE_KEYS.MESSAGES);
    } catch (e) {
      console.error('[GhostMail] Failed to clear email:', e);
    }
  },

  saveMessages(messages: EmailMessage[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
    } catch (e) {
      console.error('[GhostMail] Failed to save messages:', e);
    }
  },

  loadMessages(): EmailMessage[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.MESSAGES);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  },

  toggleFavorite(messageId: string): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.FAVORITES);
      const favorites = raw ? JSON.parse(raw) : [];
      const index = favorites.indexOf(messageId);
      if (index > -1) {
        favorites.splice(index, 1);
      } else {
        favorites.push(messageId);
      }
      localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(favorites));
    } catch (e) {
      console.error('[GhostMail] Failed to toggle favorite:', e);
    }
  },

  isFavorite(messageId: string): boolean {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.FAVORITES);
      const favorites = raw ? JSON.parse(raw) : [];
      return favorites.includes(messageId);
    } catch {
      return false;
    }
  },

  clearAll(): void {
    try {
      Object.values(STORAGE_KEYS).forEach(key => localStorage.removeItem(key));
    } catch (e) {
      console.error('[GhostMail] Failed to clear storage:', e);
    }
  },
};