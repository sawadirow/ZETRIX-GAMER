export interface TempEmail {
  address: string;
  username: string;
  domain: string;
  createdAt: number;
  expiresAt: number;
  token?: string;
  accountId?: string;
}

export interface EmailMessage {
  id: string;
  from: { address: string; name: string };
  to: Array<{ address: string; name: string }>;
  subject: string;
  intro: string;
  text: string;
  html: string[];
  hasAttachments: boolean;
  attachments: EmailAttachment[];
  size: number;
  createdAt: string;
  updatedAt: string;
  isRead: boolean;
  isFavorite?: boolean;
}

export interface EmailAttachment {
  id: string;
  filename: string;
  contentType: string;
  size: number;
  downloadUrl?: string;
}

export interface MailTmAccount {
  id: string;
  address: string;
  quota: number;
  used: number;
  isDisabled: boolean;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface MailTmMessage {
  id: string;
  accountId: string;
  msgid: string;
  from: { address: string; name: string };
  to: Array<{ address: string; name: string }>;
  subject: string;
  intro: string;
  seen: boolean;
  isDeleted: boolean;
  hasAttachments: boolean;
  size: number;
  downloadUrl: string;
  createdAt: string;
  updatedAt: string;
}

export interface MailTmMessageDetail extends MailTmMessage {
  text: string;
  html: string[];
  attachments: EmailAttachment[];
}