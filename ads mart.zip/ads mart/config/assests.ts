import assetsData from "./assets.json";

type AssetMap = Record<string, string>;

const rootWindow = window as Window & {
  getReplacedAssets?: (assets: AssetMap) => void;
};

rootWindow.getReplacedAssets?.(assetsData as AssetMap);

export default assetsData;
