import assetsData from '@/config/assets';
import { useEffect, useRef, useState } from 'react';
import { aippyTweaks } from '@aippy/runtime/tweaks';
import tweaksConfig from '@/config/tweaksConfig.json';
import { storage } from '@/utils/storage';
import { MailService } from '@/services/mailService';
import type { TempEmail } from '@/types/email';
import ParticleBackground from '@/components/ParticleBackground';
import LandingPage from '@/pages/LandingPage';
import InboxPage from '@/pages/InboxPage';
import ApiDocsPage from '@/pages/ApiDocsPage';
import ReportPage from '@/pages/ReportPage';
import Toast from '@/components/Toast';

const tweaks = aippyTweaks(tweaksConfig);

type AppState = 'landing' | 'inbox' | 'api' | 'report';

const THEMES = {
  cyber: { primary: '#00d9ff', accent: '#b026ff', bg: '#000000' },
  emerald: { primary: '#10b981', accent: '#3b82f6', bg: '#000000' },
  ruby: { primary: '#ef4444', accent: '#f59e0b', bg: '#000000' },
  gold: { primary: '#fbbf24', accent: '#f97316', bg: '#000000' },
};

const App = () => {
  const primaryGlowTweak = tweaks.primaryGlow.useState();
  const accentGlowTweak = tweaks.accentGlow.useState();
  const bgDarkTweak = tweaks.bgDark.useState();
  const themeMode = tweaks.themeMode.useState();
  const enableEmoji = tweaks.enableEmoji.useState();
  const enablePhone = tweaks.enablePhone.useState();
  const emailLifetime = tweaks.emailLifetime.useState();
  const refreshInterval = tweaks.refreshInterval.useState();
  const soundEnabled = tweaks.soundEnabled.useState();
  const particlesEnabled = tweaks.particlesEnabled.useState();

  const [appState, setAppState] = useState<AppState>('landing');
  const [email, setEmail] = useState<TempEmail | null>(null);
  const [user, setUser] = useState<{ nickname: string; id: string } | null>(null);
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const newEmailSoundRef = useRef<HTMLAudioElement | null>(null);
  const toastClickSoundRef = useRef<HTMLAudioElement | null>(null);
  const bgmRef = useRef<HTMLAudioElement | null>(null);

  const activeTheme = THEMES[themeMode as keyof typeof THEMES] || THEMES.cyber;
  const primaryGlow = themeMode === 'cyber' ? primaryGlowTweak : activeTheme.primary;
  const accentGlow = themeMode === 'cyber' ? accentGlowTweak : activeTheme.accent;
  const bgDark = themeMode === 'cyber' ? bgDarkTweak : activeTheme.bg;

  useEffect(() => {
    const currentUser = storage.getCurrentUser();
    if (currentUser) {
      setUser({ nickname: currentUser.nickname, id: currentUser.id });
      setApiKey(currentUser.apiKey || null);
    }

    const savedEmail = storage.loadEmail();
    if (savedEmail) {
      setEmail(savedEmail);
      setAppState('inbox');
    }
  }, []);

  useEffect(() => {
    if (!newEmailSoundRef.current) newEmailSoundRef.current = new Audio(assetsData.AUDIO_KACL);
    if (!toastClickSoundRef.current) toastClickSoundRef.current = new Audio(assetsData.AUDIO_IZQD);
    if (!bgmRef.current) {
      bgmRef.current = new Audio(assetsData.AUDIO_PWLN);
      bgmRef.current.loop = true;
      bgmRef.current.volume = 0.2;
    }
  }, []);

  const playToastSound = () => {
    if (!soundEnabled || !toastClickSoundRef.current) return;
    toastClickSoundRef.current.currentTime = 0;
    toastClickSoundRef.current.play().catch(() => {});
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
    playToastSound();
  };

  const generateEmail = async () => {
    setLoading(true);
    try {
      const domains = await MailService.getDomains();
      const username = MailService.generateRandomUsername();
      const newEmail = await MailService.createTempEmail(username, domains[0]);
      newEmail.expiresAt = Date.now() + emailLifetime * 60 * 1000;
      setEmail(newEmail);
      storage.saveEmail(newEmail);
      setAppState('inbox');
      showToast('Email generated successfully!', 'success');
      if (bgmRef.current && soundEnabled) {
        bgmRef.current.play().catch(() => {});
      }
    } catch (error) {
      console.error('[Aippy] Failed to generate email:', error);
      showToast(error instanceof Error ? error.message : 'Failed to generate email', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleExpire = () => {
    storage.clearEmail();
    setEmail(null);
    showToast('Email expired', 'info');
  };

  const handleBack = () => {
    setAppState('landing');
    if (bgmRef.current) {
      bgmRef.current.pause();
    }
  };

  const handleLogout = () => {
    storage.logoutCurrentUser();
    storage.clearEmail();
    setUser(null);
    setApiKey(null);
    setEmail(null);
    setAppState('landing');
    showToast('Logged out successfully', 'info');
    if (bgmRef.current) {
      bgmRef.current.pause();
      bgmRef.current.currentTime = 0;
    }
  };


  return (
    <div className="min-h-screen relative transition-colors duration-500" style={{ backgroundColor: bgDark }}>
      <ParticleBackground color={primaryGlow} enabled={particlesEnabled} />

      <div className="relative z-10">
        {loading ? (
          <div className="min-h-screen flex flex-col items-center justify-center">
            <div
              className="w-16 h-16 border-4 border-t-transparent rounded-full animate-spin mb-4"
              style={{ borderColor: `${primaryGlow} transparent transparent transparent` }}
            />
            <p className="text-white/60 font-black uppercase tracking-widest text-[10px]">Generating identity...</p>
          </div>
        ) : appState === 'landing' ? (
          <LandingPage
            onGetStarted={generateEmail}
            onOpenApiDocs={() => setAppState('api')}
            onOpenReport={() => setAppState('report')}
            primaryGlow={primaryGlow}
            accentGlow={accentGlow}
            enablePhone={enablePhone}
            isLoggedIn={!!user}
          />
        ) : appState === 'api' ? (
          <ApiDocsPage onBack={handleBack} primaryGlow={primaryGlow} accentGlow={accentGlow} />
        ) : appState === 'report' ? (
          <ReportPage
            onBack={handleBack}
            primaryGlow={primaryGlow}
            accentGlow={accentGlow}
            soundEnabled={soundEnabled}
            apiKey={apiKey || undefined}
          />
        ) : (
          <InboxPage
            email={email || undefined}
            user={user || undefined}
            apiKey={apiKey || undefined}
            onBack={handleBack}
            onLogout={handleLogout}
            onExpire={handleExpire}
            primaryGlow={primaryGlow}
            accentGlow={accentGlow}
            refreshInterval={refreshInterval}
            soundEnabled={soundEnabled}
            onNewEmail={() => {}}
            enableEmoji={enableEmoji}
            onRegenerateEmail={generateEmail}
          />
        )}
      </div>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
};

export default App;