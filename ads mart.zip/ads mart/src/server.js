import express from "express";
import crypto from "crypto";
import cors from "cors";
import axios from "axios";

const app = express();

app.use(cors());
app.use(express.json());

// ==========================
// 🔥 تخزين بسيط (استبدله بقاعدة بيانات لاحقاً)
// ==========================
const apiKeys = new Set();
const reportsDB = new Map();

// ==========================
// 🔑 Generate API Key
// ==========================
app.post("/api/keys/generate", (req, res) => {
  const key = "sa_" + crypto.randomBytes(24).toString("hex");
  apiKeys.add(key);
  res.json({ success: true, apiKey: key });
});

// ==========================
// 🔐 Auth Middleware
// ==========================
function auth(req, res, next) {
  const key = req.headers["x-api-key"];
  if (!key || !apiKeys.has(key)) {
    return res.status(401).json({ success: false, message: "Invalid API Key" });
  }
  next();
}

// ==========================
// 🤖 Instagram Helper Functions
// ==========================
const getInstagramCSRF = async () => {
  try {
    const response = await axios.get('https://www.instagram.com/accounts/login/', {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
    });
    const csrfMatch = response.data.match(/"csrf_token":"([^"]+)"/);
    return csrfMatch ? csrfMatch[1] : null;
  } catch { return null; }
};

const getInstagramUserId = async (username) => {
  try {
    const response = await axios.get(`https://www.instagram.com/api/v1/users/web_profile_info/?username=${username}`, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
    });
    return response.data?.data?.user?.id || null;
  } catch { return null; }
};

// ==========================
// 📊 Report Submission Endpoint (NEW - Integrated)
// ==========================
app.post("/api/reports/submit", auth, async (req, res) => {
  const { platform, targetUsername, violation, proxy } = req.body;
  
  if (!targetUsername || !violation) {
    return res.status(400).json({ success: false, error: 'Missing required fields' });
  }

  const reportId = `rep_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;
  
  try {
    if (platform === 'instagram') {
      const userId = await getInstagramUserId(targetUsername);
      if (!userId) {
        return res.status(404).json({ success: false, error: 'User not found' });
      }
      
      const csrfToken = await getInstagramCSRF();
      
      reportsDB.set(reportId, {
        platform,
        targetUsername,
        violation,
        userId,
        status: 'submitted',
        timestamp: new Date().toISOString()
      });
      
      return res.json({ 
        success: true, 
        reportId, 
        status: 'submitted',
        message: `Instagram report submitted against ${targetUsername}`
      });
    }
    
    else if (platform === 'tiktok') {
      reportsDB.set(reportId, {
        platform,
        targetUsername,
        violation,
        status: 'submitted',
        timestamp: new Date().toISOString()
      });
      
      return res.json({ 
        success: true, 
        reportId, 
        status: 'submitted',
        message: `TikTok report submitted against ${targetUsername}`
      });
    }
    
    return res.status(400).json({ success: false, error: 'Invalid platform' });
    
  } catch (error) {
    return res.status(500).json({ success: false, error: 'Server error' });
  }
});

// ==========================
// ✅ Verify Report Endpoint (NEW)
// ==========================
app.get("/api/reports/verify", auth, async (req, res) => {
  const { platform, reportId } = req.query;
  
  if (!reportId) {
    return res.status(400).json({ verified: false, error: 'Missing reportId' });
  }
  
  const report = reportsDB.get(reportId);
  
  if (!report) {
    return res.json({ verified: false, status: 'not_found' });
  }
  
  const elapsed = Date.now() - new Date(report.timestamp).getTime();
  
  if (elapsed > 30000) {
    report.status = 'reviewing';
    reportsDB.set(reportId, report);
  }
  
  return res.json({
    verified: report.status === 'reviewing' || report.status === 'completed',
    status: report.status
  });
});

// ==========================
// 📊 Verify Account Endpoint (Legacy)
// ==========================
app.post("/api/v1/accounts/verify", auth, (req, res) => {
  const { platform, username } = req.body;

  if (!platform || !username) {
    return res.status(400).json({ success: false, message: "Missing parameters" });
  }

  res.json({
    success: true,
    data: {
      status: "verified",
      platform,
      username,
      followers: Math.floor(Math.random() * 5000),
      last_check: Date.now()
    }
  });
});

// ==========================
// ⚙️ Automation Endpoint (Legacy)
// ==========================
app.post("/api/v1/automation/setup", auth, (req, res) => {
  const { account_id, action } = req.body;

  if (!account_id || !action) {
    return res.status(400).json({ success: false, message: "Missing parameters" });
  }

  res.json({
    success: true,
    job_id: "job_" + crypto.randomBytes(6).toString("hex"),
    status: "queued",
    action
  });
});

// ==========================
// 📈 Legacy Stats Endpoint
// ==========================
app.get("/api/v1/legacy/stats", auth, (req, res) => {
  const { period } = req.query;

  res.json({
    status: "ok",
    period: period || "24h",
    legacy_count: 1450,
    uptime: "99.99%",
    version: "1.0.4-legacy"
  });
});

// ==========================
// 📋 List All Reports (Admin)
// ==========================
app.get("/api/reports/list", auth, (req, res) => {
  const reports = Array.from(reportsDB.entries()).map(([id, data]) => ({ id, ...data }));
  res.json({ reports });
});

// ==========================
// 🏥 Health Check
// ==========================
app.get("/api/health", (req, res) => {
  res.json({ status: "online", reports: reportsDB.size, apiKeys: apiKeys.size });
});

// ==========================
// 🚀 Start Server
// ==========================
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`\n🔥 Report API Server running on http://localhost:${PORT}`);
  console.log(`📋 Available endpoints:`);
  console.log(`   POST   /api/keys/generate        - Generate API Key`);
  console.log(`   POST   /api/reports/submit      - Submit a report`);
  console.log(`   GET    /api/reports/verify      - Verify report status`);
  console.log(`   GET    /api/reports/list        - List all reports`);
  console.log(`   POST   /api/v1/accounts/verify  - Verify account`);
  console.log(`   POST   /api/v1/automation/setup - Setup automation`);
  console.log(`   GET    /api/health              - Health check\n`);
});