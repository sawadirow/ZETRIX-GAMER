import '@/utils/assetOverridesCleanup';
import { createRoot } from 'react-dom/client'
import './index.css'

const root = createRoot(document.getElementById('root')!);

void import('@/App.tsx').then(({ default: App }) => {
  root.render(<App />);
});
