import assetsData from '@/config/assets';
import { useState } from 'react';
import { ChevronDown, Shield, Zap, Clock, Globe, X, CheckCircle2, Key, Flag, Layout } from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
  onOpenApiDocs: () => void;
  onOpenReport: () => void;
  primaryGlow: string;
  accentGlow: string;
  enablePhone?: boolean;
  isLoggedIn?: boolean;
}

type ModalType = 'privacy' | 'terms' | 'api' | null;

interface ModalProps {
  title: string;
  content: React.ReactNode;
  onClose: () => void;
  primaryGlow: string;
  accentGlow: string;
}

const Modal = ({ title, content, onClose, primaryGlow, accentGlow }: ModalProps) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-md bg-black/60 animate-in fade-in duration-300">
    <div className="relative w-full max-w-2xl max-h-[80vh] overflow-y-auto rounded-3xl border border-white/10 bg-[#121218] p-8 shadow-2xl custom-scrollbar animate-in zoom-in-95 duration-300">
      <button onClick={onClose} className="absolute right-4 top-4 rounded-full p-2 text-white/40 transition-colors hover:bg-white/10">
        <X size={24} />
      </button>
      <h2 className="mb-6 text-3xl font-black" style={{ color: primaryGlow }}>{title}</h2>
      <div className="prose prose-invert max-w-none text-white/70 leading-relaxed">{content}</div>
      <button
        onClick={onClose}
        className="mt-8 w-full rounded-xl py-4 font-bold text-white transition-all hover:scale-[1.02]"
        style={{ background: `linear-gradient(135deg, ${primaryGlow}, ${accentGlow})` }}
      >
        I Understand
      </button>
    </div>
  </div>
);

const AdPlaceholder = ({ label, height = "h-24", className = "" }: { label: string; height?: string; className?: string }) => (
  <div className={`mx-auto w-full max-w-3xl rounded-3xl border border-white/10 bg-white/5 p-4 backdrop-blur-md flex flex-col justify-center items-center gap-2 ${height} ${className}`}>
    <div className="flex items-center gap-2">
      <Layout size={14} className="text-white/20" />
      <p className="text-[10px] font-black uppercase tracking-[0.4em] text-white/30">{label}</p>
    </div>
    <div className="h-1 w-20 rounded-full bg-white/5" />
  </div>
);

const featureCards = [
  { icon: Zap, title: 'Instant Generation', desc: 'Create temporary emails in milliseconds. No forms, no wait.' },
  { icon: Clock, title: 'Self-Destruct', desc: 'Every inbox expires automatically with no recovery path.' },
  { icon: Shield, title: 'Privacy First', desc: 'Built for anonymous workflows and quick disposable access.' },
];

const LandingPage = ({ onGetStarted, onOpenApiDocs, onOpenReport, primaryGlow, accentGlow, enablePhone, isLoggedIn }: LandingPageProps) => {
  const [modal, setModal] = useState<ModalType>(null);

  return (
    <div className="min-h-screen overflow-y-auto scroll-smooth">
      <section className="relative min-h-screen px-4 py-20 flex flex-col items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/50 pointer-events-none" />

        <div className="relative z-10 mx-auto max-w-5xl text-center">
          {/* TOP AD BANNER */}
          <div className="mb-12">
            <AdPlaceholder label="Leaderboard Ad 728x90" height="h-20" />
          </div>

          <div className="relative mb-6 inline-block group">
            <div className="absolute -inset-4 rounded-3xl bg-gradient-to-r from-cyan-500 to-purple-600 blur-2xl opacity-20 transition-opacity duration-500 group-hover:opacity-40" />
            <img
              src={assetsData.IMAGE_VQEM}
              alt="GhostMail"
              className="relative mx-auto h-24 w-24 rounded-2xl object-cover"
              style={{ boxShadow: `0 0 40px ${primaryGlow}40` }}
            />
          </div>

          <h1
            className="mb-6 text-6xl font-black tracking-tighter md:text-8xl"
            style={{
              background: `linear-gradient(135deg, ${primaryGlow}, ${accentGlow})`,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              textShadow: `0 0 60px ${primaryGlow}60`,
            }}
          >
            GhostMail
          </h1>

          <p className="mx-auto mb-8 max-w-2xl text-xl leading-relaxed text-white/70 md:text-2xl">
            Temporary digital identities that vanish without a trace. Fast, private, and ready for testing.
          </p>

          {/* AD ABOVE BUTTON */}
          <div className="mb-8">
            <AdPlaceholder label="Banner Above Generate Button" height="h-24" />
          </div>

          <div className="mx-auto flex flex-col items-center justify-center gap-3 sm:flex-row mb-12">
            <button
              onClick={onGetStarted}
              className="rounded-full px-10 py-5 text-xl font-black text-white transition-all duration-300 hover:scale-105 active:scale-95 shadow-2xl"
              style={{
                background: `linear-gradient(135deg, ${primaryGlow}, ${accentGlow})`,
                boxShadow: `0 0 50px ${primaryGlow}60, 0 10px 40px rgba(0,0,0,0.4)`,
              }}
            >
              {isLoggedIn ? 'Open Inbox' : 'Generate Ghost Identity'}
            </button>
            <button
              onClick={onOpenApiDocs}
              className="flex items-center gap-3 rounded-full border border-white/10 bg-white/5 px-8 py-5 text-lg font-bold text-white/80 backdrop-blur-md transition-all duration-300 hover:bg-white/10 hover:text-white"
            >
              <Key size={20} style={{ color: primaryGlow }} />
              API Docs
            </button>
            <button
              onClick={onOpenReport}
              className="flex items-center gap-3 rounded-full border border-red-500/20 bg-red-500/5 px-8 py-5 text-lg font-bold text-red-300 backdrop-blur-md transition-all duration-300 hover:bg-red-500/10 hover:text-red-200"
            >
              <Flag size={20} className="text-red-400" />
              Report Center
            </button>
          </div>

          {/* AD BELOW HERO */}
          <div className="mb-12">
            <AdPlaceholder label="Hero Section Lower Banner" height="h-32" />
          </div>

          <div className="relative mx-auto mb-12 inline-block max-w-xs animate-in fade-in slide-in-from-bottom-4 duration-700 md:max-w-md">
            <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-white/20 to-transparent blur-sm" />
            <img
              src={assetsData.IMAGE_UDRE}
              alt="Hero preview"
              className="relative mx-auto rounded-2xl border border-white/10 shadow-2xl"
              style={{ boxShadow: `0 0 80px ${primaryGlow}30` }}
            />
          </div>

          <div className="mt-12 grid max-w-4xl gap-4 md:grid-cols-2 lg:grid-cols-4">
            {(enablePhone ? featureCards : [featureCards[0], { icon: Globe, title: 'Global Routing', desc: 'Designed for broad compatibility across regions and devices.' }, featureCards[2]]).map((feature, index) => (
              <div
                key={feature.title}
                className="rounded-3xl border border-white/5 bg-white/2 p-7 text-left backdrop-blur-xl transition-all duration-500 hover:bg-white/5 hover:border-white/10"
                style={{ animationDelay: `${index * 0.08}s`, boxShadow: `0 0 40px ${primaryGlow}05` }}
              >
                <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/5 text-white" style={{ color: accentGlow }}>
                  <feature.icon size={32} />
                </div>
                <h3 className="mb-2 text-2xl font-bold text-white">{feature.title}</h3>
                <p className="text-sm leading-relaxed text-white/50">{feature.desc}</p>
              </div>
            ))}
          </div>

          {/* AD BETWEEN FEATURES */}
          <div className="my-12">
            <AdPlaceholder label="Native In-feed Ad 336x280" height="h-64" />
          </div>

          <div className="mx-auto mt-8 grid max-w-4xl gap-4 md:grid-cols-2">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 text-left backdrop-blur-xl">
              <p className="text-[9px] font-black uppercase tracking-[0.35em] text-white/40">Quick Access</p>
              <p className="mt-3 text-lg font-bold text-white">No registration required</p>
              <p className="mt-1 text-[10px] uppercase tracking-widest text-white/35">Open the dashboard, create email, and start using it immediately.</p>
            </div>
            <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-red-500/5 to-orange-500/5 p-6 text-left backdrop-blur-xl">
              <p className="text-[9px] font-black uppercase tracking-[0.35em] text-red-300/80">Premium Access</p>
              <p className="mt-3 text-lg font-bold text-white">Advanced Control</p>
              <p className="mt-1 text-[10px] uppercase tracking-widest text-white/35">Manage proxies and automation scripts from one interface.</p>
            </div>
          </div>

          <div className="mt-8 flex items-center justify-center gap-2 text-sm font-bold uppercase tracking-widest text-white/40">
            <CheckCircle2 size={16} className="text-green-500" />
            No Registration Required
          </div>
        </div>

        <ChevronDown className="absolute bottom-8 animate-bounce text-white/20" size={32} />
      </section>

      {/* AD BEFORE FAQ */}
      <section className="px-4 py-8">
        <AdPlaceholder label="Mid-Page Transition Banner" height="h-28" />
      </section>

      <section className="border-y border-white/5 bg-white/[0.02] px-4 py-12">
        <div className="mx-auto flex max-w-6xl flex-wrap justify-center gap-12 opacity-60 grayscale transition-all duration-700 hover:grayscale-0">
          <div className="text-center">
            <p className="text-3xl font-black text-white">2.4M+</p>
            <p className="text-xs font-bold uppercase tracking-tighter text-white/40">Emails Processed</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-black text-white">99.9%</p>
            <p className="text-xs font-bold uppercase tracking-tighter text-white/40">Uptime Status</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-black text-white">0kb</p>
            <p className="text-xs font-bold uppercase tracking-tighter text-white/40">Data Stored</p>
          </div>
        </div>
      </section>

      <section className="relative px-4 py-20">
        <div className="mx-auto max-w-4xl">
          <h2 className="mb-10 text-center text-4xl font-black" style={{ color: primaryGlow }}>System Intelligence</h2>
          <div className="space-y-4">
            {[
              ['How long do the ghost addresses last?', 'By default, addresses last 60 minutes.'],
              ['Can I choose my own username?', 'Yes. The inbox updates with a fresh identity every time you generate one.'],
              ['Are attachments supported?', 'Yes, supported messages can include downloadable attachments.'],
            ].map(([q, a]) => (
              <details key={q} className="group rounded-2xl border border-white/5 bg-white/2 p-6 transition-all duration-300 hover:bg-white/5">
                <summary className="flex cursor-pointer list-none items-center justify-between font-bold text-lg text-white/80 group-open:mb-4 group-open:text-white">
                  {q}
                  <ChevronDown size={20} className="text-white/20 transition-transform group-open:rotate-180" />
                </summary>
                <p className="text-white/50 leading-relaxed">{a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* AD ABOVE FOOTER */}
      <section className="px-4 py-12">
        <AdPlaceholder label="Pre-Footer Banner Ad" height="h-32" />
      </section>

      <footer className="border-t border-white/5 bg-black px-4 py-20">
        <div className="mx-auto flex max-w-6xl flex-col items-center">
          <div className="mb-8 flex cursor-pointer items-center gap-2" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500 to-purple-600 shadow-lg">
              <Shield size={20} className="text-white" />
            </div>
            <span className="text-2xl font-black tracking-tighter text-white">GhostMail</span>
          </div>

          <p className="mb-10 max-w-sm text-center text-sm leading-relaxed text-white/30">
            GhostMail — the premium standard for temporary communication.
          </p>

          <div className="flex flex-wrap justify-center gap-8 text-sm font-bold uppercase tracking-widest">
            <button onClick={() => setModal('privacy')} className="text-white/40 transition-colors hover:text-white">Privacy</button>
            <button onClick={() => setModal('terms')} className="text-white/40 transition-colors hover:text-white">Terms</button>
            <button onClick={onOpenApiDocs} className="text-white/40 transition-colors hover:text-white">API</button>
          </div>
        </div>
      </footer>

      {modal === 'privacy' && (
        <Modal
          title="Privacy Protocol"
          onClose={() => setModal(null)}
          primaryGlow={primaryGlow}
          accentGlow={accentGlow}
          content={
            <div className="space-y-4">
              <p>We do not store your personal identity. Every inbox is transient and disposable.</p>
              <p>Messages are removed automatically when the session expires.</p>
            </div>
          }
        />
      )}

      {modal === 'terms' && (
        <Modal
          title="Terms of Service"
          onClose={() => setModal(null)}
          primaryGlow={primaryGlow}
          accentGlow={accentGlow}
          content={
            <div className="space-y-4">
              <p>Use the service responsibly and only for lawful purposes.</p>
              <p>Temporary identities are transient and cannot be restored after expiration.</p>
            </div>
          }
        />
      )}

      {modal === 'api' && (
        <Modal
          title="Developer API"
          onClose={() => setModal(null)}
          primaryGlow={primaryGlow}
          accentGlow={accentGlow}
          content={
            <div className="space-y-4">
              <p>Use the API docs to integrate workflow automation and email retrieval patterns.</p>
              <div className="rounded-lg border border-white/5 bg-black/40 p-4 font-mono text-xs">
                <p className="text-cyan-400">GET /v1/generate</p>
                <p className="mt-4 text-cyan-400">GET /v1/inbox/:address</p>
              </div>
            </div>
          }
        />
      )}
    </div>
  );
};

export default LandingPage;