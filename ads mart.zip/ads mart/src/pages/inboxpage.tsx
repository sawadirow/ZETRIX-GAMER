import assetsData from "@/config/assets";
import { useState, useEffect, useCallback, useRef } from 'react';
import { Copy, RefreshCw, Mail, Trash2, Star, Search, ArrowLeft, Download, Paperclip, X, Info, Globe, CheckCircle, FileDown, Key, Smartphone, Users, UserPlus, ShieldCheck, Zap, UserCircle, Flag, Code, Layout } from 'lucide-react';
import { vibrate } from '@aippy/runtime/device';
import { useAudioContext } from '@aippy/runtime/audio';
import type { TempEmail, EmailMessage } from '@/types/email';
import type { ResidentialProxy } from '@/types/proxy';
import { MailService } from '@/services/mailService';
import { ProxyService } from '@/services/proxyService';
import { storage } from '@/utils/storage';
import CountdownTimer from '@/components/CountdownTimer';
import Toast from '@/components/Toast';
import ApiDocsPage from '@/pages/ApiDocsPage';
import ReportPage from '@/pages/ReportPage';
import CodeControlCenter from '@/components/CodeControlCenter';

interface InboxPageProps {
  email?: TempEmail;
  user?: {
    nickname: string;
    id: string;
  };
  apiKey?: string;
  onBack: () => void;
  onLogout: () => void;
  onExpire: () => void;
  primaryGlow: string;
  accentGlow: string;
  refreshInterval: number;
  soundEnabled: boolean;
  onNewEmail: () => void;
  enableEmoji: boolean;
  onRegenerateEmail: () => void;
}

type TikTokStep = 'idle' | 'creating' | 'setup_profile' | 'setup_bio' | 'following' | 'growth' | 'success' | 'failed';

interface TikTokAccount {
  username: string;
  password: string;
  email: string;
  followers: number;
  status: 'pending' | 'created' | 'ready' | 'growing';
  setupComplete: boolean;
  followSuccess: boolean;
  lastCode?: string;
}

const AdPlaceholder = ({ label, height = "h-20", className = "" }: { label: string; height?: string; className?: string }) => (
  <div className={`mx-auto w-full rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-md flex flex-col justify-center items-center gap-1 ${height} ${className}`}>
    <div className="flex items-center gap-2">
      <Layout size={12} className="text-white/20" />
      <p className="text-[8px] font-black uppercase tracking-[0.4em] text-white/30">{label}</p>
    </div>
    <div className="h-0.5 w-12 rounded-full bg-white/5" />
  </div>
);

const SMART_HELPER_MESSAGES: Record<TikTokStep, string> = {
  idle: "Ready to start the automation. Ensure your proxy pool is active.",
  creating: "Automation is filling the registration form. If a captcha appears, solve it manually.",
  setup_profile: "Uploading a high-quality neon-themed avatar. You can manually adjust the crop if needed.",
  setup_bio: "Writing a creative bio with relevant hashtags. Check for any banned keywords.",
  following: "Navigating to the target profile. Watch the 'Follow' button press.",
  growth: "Starting mutual follow loop to reach the target of ~50 followers per account.",
  success: "All operations complete. Accounts are now aged and ready for engagement.",
  failed: "Automation stalled. Check your API limits or network stability."
};

const InboxPage = ({
  email,
  user,
  apiKey,
  onBack,
  onLogout,
  onExpire,
  primaryGlow,
  accentGlow,
  refreshInterval,
  soundEnabled,
  onNewEmail,
  enableEmoji,
  onRegenerateEmail
}: InboxPageProps) => {
  const [activeTab, setActiveTab] = useState<'email' | 'proxy' | 'tiktok' | 'api' | 'report' | 'code'>('email');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [proxies, setProxies] = useState<ResidentialProxy[]>([]);
  const [selectedProxy, setSelectedProxy] = useState<ResidentialProxy | null>(null);
  const [proxyFormat, setProxyFormat] = useState<'url' | 'simple' | 'curl'>('url');
  const [proxyCountToGenerate, setProxyCountToGenerate] = useState(5);

  // Interstitial State
  const [showInterstitial, setShowInterstitial] = useState(false);

  // TikTok State
  const [tikTokStep, setTikTokStep] = useState<TikTokStep>('idle');
  const [tikTokAccounts, setTikTokAccounts] = useState<TikTokAccount[]>([]);
  const [targetUsername, setTargetUsername] = useState('');
  const [accountCount, setAccountCount] = useState(5);
  const [showHelper, setShowHelper] = useState(true);
  const [messages, setMessages] = useState<EmailMessage[]>([]);
  const [selectedMessage, setSelectedMessage] = useState<EmailMessage | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [toast, setToast] = useState<{
    message: string;
    type: 'success' | 'error' | 'info';
  } | null>(null);
  const [lastMessageCount, setLastMessageCount] = useState(0);

  // Audio Refs
  const startSoundRef = useRef<HTMLAudioElement | null>(null);
  const successSoundRef = useRef<HTMLAudioElement | null>(null);
  const failSoundRef = useRef<HTMLAudioElement | null>(null);
  const {
    unlock
  } = useAudioContext();

  useEffect(() => {
    startSoundRef.current = new Audio(assetsData.AUDIO_KDVX);
    successSoundRef.current = new Audio(assetsData.AUDIO_HLRU);
    failSoundRef.current = new Audio(assetsData.AUDIO_VQKT);
    const savedAccounts = storage.getTikTokAccounts();
    if (savedAccounts.length > 0) {
      setTikTokAccounts(savedAccounts);
    }
  }, []);

  const playSound = (audioRef: React.RefObject<HTMLAudioElement | null>) => {
    if (soundEnabled && audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(() => {});
    }
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({
      message,
      type
    });
  };

  useEffect(() => {
    if (proxies.length === 0) {
      const initialProxies = ProxyService.generateProxyPool(5, 60);
      setProxies(initialProxies);
    }
  }, [proxies.length]);

  const generateMoreProxies = () => {
    setLoading(true);
    setTimeout(() => {
      const newProxies = ProxyService.generateProxyPool(proxyCountToGenerate, 60);
      setProxies(prev => [...prev, ...newProxies]);
      showToast(`Generated ${newProxies.length} new residential proxies!`, 'success');
      setLoading(false);
      vibrate(50);
    }, 1500);
  };

  const copyProxy = (proxy: ResidentialProxy, format: 'url' | 'simple' | 'curl' = 'url') => {
    let text = '';
    switch (format) {
      case 'url':
        text = ProxyService.formatProxyUrl(proxy);
        break;
      case 'simple':
        text = ProxyService.formatProxySimple(proxy);
        break;
      case 'curl':
        text = ProxyService.formatProxyForCurl(proxy);
        break;
    }
    navigator.clipboard.writeText(text);
    showToast(`Proxy copied (${format.toUpperCase()})!`, 'success');
    vibrate(50);
  };

  const exportAllProxies = () => {
    const exported = ProxyService.exportProxies(proxies, proxyFormat);
    navigator.clipboard.writeText(exported);
    showToast(`Exported ${proxies.length} proxies to clipboard!`, 'success');
    vibrate(50);
  };

  const deleteProxy = (proxyId: string) => {
    setProxies(prev => prev.filter(p => p.id !== proxyId));
    if (selectedProxy?.id === proxyId) {
      setSelectedProxy(null);
    }
    showToast('Proxy removed', 'success');
    vibrate(50);
  };

  const copyEmail = () => {
    if (email) {
      navigator.clipboard.writeText(email.address);
      showToast('Email copied to clipboard!', 'success');
      vibrate(50);
    }
  };

  const fetchMessages = useCallback(async () => {
    if (!email?.token) return;
    try {
      const msgs = await MailService.getMessages(email.token);
      const withFavorites = msgs.map(msg => ({
        ...msg,
        isFavorite: storage.isFavorite(msg.id)
      }));
      if (withFavorites.length > lastMessageCount) {
        if (soundEnabled && lastMessageCount > 0) {
          onNewEmail();
        }
        showToast(`${withFavorites.length - lastMessageCount} new message(s)!`, 'success');
      }
      setLastMessageCount(withFavorites.length);
      setMessages(withFavorites);
      storage.saveMessages(withFavorites);
    } catch (error) {
      console.error('[GhostMail] Failed to fetch messages:', error);
    }
  }, [email?.token, lastMessageCount, soundEnabled, onNewEmail]);

  const refreshInbox = async () => {
    setLoading(true);
    await fetchMessages();
    setLoading(false);
    vibrate(30);
  };

  useEffect(() => {
    const savedMessages = storage.loadMessages();
    if (savedMessages.length > 0) {
      setMessages(savedMessages);
      setLastMessageCount(savedMessages.length);
    }
    fetchMessages();
    const interval = setInterval(fetchMessages, refreshInterval * 1000);
    return () => clearInterval(interval);
  }, [fetchMessages, refreshInterval]);

  const openMessage = async (msg: EmailMessage) => {
    if (!email?.token) return;
    const fullMessage = await MailService.getMessage(email.token, msg.id);
    if (fullMessage) {
      setSelectedMessage({
        ...fullMessage,
        isFavorite: storage.isFavorite(fullMessage.id)
      });
      if (!fullMessage.isRead) {
        await MailService.markAsRead(email.token, msg.id);
        fetchMessages();
      }
    }
  };

  const deleteMessage = async (msgId: string) => {
    if (!email?.token) return;
    try {
      await MailService.deleteMessage(email.token, msgId);
      setMessages(prev => prev.filter(m => m.id !== msgId));
      if (selectedMessage?.id === msgId) {
        setSelectedMessage(null);
      }
      showToast('Message deleted', 'success');
      vibrate(50);
    } catch {
      showToast('Failed to delete message', 'error');
    }
  };

  const handleRegenerate = () => {
    setShowInterstitial(true);
    vibrate(60);
  };

  const confirmRegenerate = () => {
    setShowInterstitial(false);
    onRegenerateEmail();
    vibrate(50);
  };

  const toggleFavorite = (msgId: string) => {
    storage.toggleFavorite(msgId);
    const isFav = storage.isFavorite(msgId);
    setMessages(prev => prev.map(m => m.id === msgId ? {
      ...m,
      isFavorite: isFav
    } : m));
    if (selectedMessage?.id === msgId) {
      setSelectedMessage(prev => prev ? {
        ...prev,
        isFavorite: isFav
      } : null);
    }
    vibrate(30);
  };

  const filteredMessages = messages.filter(msg => msg.subject.toLowerCase().includes(searchQuery.toLowerCase()) || msg.from.address.toLowerCase().includes(searchQuery.toLowerCase()));

  const downloadAttachment = (att: any) => {
    showToast('Preparing download...', 'info');
    setTimeout(() => {
      showToast(`Downloaded ${att.filename}`, 'success');
      vibrate(50);
    }, 1500);
  };

  const runTikTokAutomation = () => {
    setTikTokStep('creating');
    playSound(startSoundRef);
    vibrate(50);
    
    setTimeout(() => setTikTokStep('setup_profile'), 2000);
    setTimeout(() => setTikTokStep('setup_bio'), 4000);
    setTimeout(() => setTikTokStep('following'), 6000);
    setTimeout(() => setTikTokStep('growth'), 8000);
    setTimeout(() => {
      setTikTokStep('success');
      playSound(successSoundRef);
      const newAccounts: TikTokAccount[] = Array.from({ length: accountCount }).map(() => ({
        username: `ghost_${Math.random().toString(36).substring(7)}`,
        password: Math.random().toString(36).substring(7),
        email: email?.address || 'ghost@mail.com',
        followers: Math.floor(Math.random() * 60),
        status: 'ready',
        setupComplete: true,
        followSuccess: true,
        lastCode: Math.floor(100000 + Math.random() * 900000).toString()
      }));
      setTikTokAccounts(prev => [...newAccounts, ...prev]);
      storage.saveTikTokAccounts([...newAccounts, ...tikTokAccounts]);
      showToast(`Successfully created ${accountCount} accounts!`, 'success');
    }, 10000);
  };

  if (selectedMessage) {
    return <div className="min-h-screen flex flex-col bg-black">
        <div className="sticky top-0 z-10 backdrop-blur-md bg-black/50 border-b border-white/10 p-4">
          <div className="flex items-center justify-between">
            <button onClick={() => setSelectedMessage(null)} className="flex items-center gap-2 text-white/80 hover:text-white transition-colors">
              <ArrowLeft size={20} />
              <span>Back</span>
            </button>
            
            <div className="flex items-center gap-2">
              <button onClick={() => toggleFavorite(selectedMessage.id)} className="p-2 rounded-lg hover:bg-white/10 transition-colors">
                <Star size={20} className={selectedMessage.isFavorite ? 'fill-yellow-400 text-yellow-400' : 'text-white/60'} />
              </button>
              <button onClick={() => deleteMessage(selectedMessage.id)} className="p-2 rounded-lg hover:bg-white/10 transition-colors text-red-400">
                <Trash2 size={20} />
              </button>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
          <div className="max-w-4xl mx-auto">
            {/* AD ABOVE MESSAGE CONTENT */}
            <div className="mb-6">
               <AdPlaceholder label="In-Message Contextual Ad" height="h-24" />
            </div>

            <h1 className="text-2xl font-bold text-white mb-4">{selectedMessage.subject}</h1>
            
            <div className="mb-6 p-4 rounded-lg border border-white/10 bg-white/5">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="text-sm text-white/60">From</p>
                  <p className="text-white">{selectedMessage.from.name || selectedMessage.from.address}</p>
                  <p className="text-xs text-white/40">{selectedMessage.from.address}</p>
                </div>
                <p className="text-xs text-white/40">
                  {new Date(selectedMessage.createdAt).toLocaleString()}
                </p>
              </div>
              
              {selectedMessage.hasAttachments && <div className="mt-3 pt-3 border-t border-white/10">
                  <p className="text-sm text-white/60 mb-2 flex items-center gap-2">
                    <Paperclip size={14} />
                    Attachments ({selectedMessage.attachments.length})
                  </p>
                  <div className="space-y-2">
                    {selectedMessage.attachments.map(att => <div key={att.id} className="flex items-center justify-between p-2 rounded bg-white/5 hover:bg-white/10 transition-colors">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-white truncate">{att.filename}</p>
                          <p className="text-xs text-white/40">
                            {(att.size / 1024).toFixed(1)} KB
                          </p>
                        </div>
                        <button onClick={() => downloadAttachment(att)} className="p-2 hover:bg-white/10 rounded transition-colors">
                          <Download size={16} className="text-white/60" />
                        </button>
                      </div>)}
                  </div>
                </div>}
            </div>
            
            <div className="prose prose-invert max-w-none overflow-x-auto pb-8">
              {selectedMessage.html.length > 0 ? <div dangerouslySetInnerHTML={{
              __html: selectedMessage.html[0]
            }} /> : <pre className="whitespace-pre-wrap text-white/80 font-sans">{selectedMessage.text || selectedMessage.intro}</pre>}
            </div>

            {/* AD BELOW MESSAGE CONTENT */}
            <div className="mt-12">
               <AdPlaceholder label="Bottom Message Ad Slot" height="h-40" />
            </div>
          </div>
        </div>
      </div>;
  }

  if (selectedProxy) {
    return <div className="min-h-screen flex flex-col bg-black">
        <div className="sticky top-0 z-10 backdrop-blur-md bg-black/50 border-b border-white/10 p-4">
          <div className="flex items-center justify-between">
            <button onClick={() => setSelectedProxy(null)} className="flex items-center gap-2 text-white/80 hover:text-white transition-colors">
              <ArrowLeft size={20} />
              <span>Back</span>
            </button>
            
            <button onClick={() => deleteProxy(selectedProxy.id)} className="p-2 rounded-lg hover:bg-white/10 transition-colors text-red-400">
              <Trash2 size={20} />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-green-500/20 to-blue-500/20 border border-green-500/30 mb-4">
                <Globe size={40} className="text-green-400" />
              </div>
              <h1 className="text-3xl font-black text-white mb-2">Residential Proxy</h1>
              <p className="text-white/40">Premium home IP • Clean reputation</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <p className="text-xs text-white/40 uppercase tracking-wider font-bold mb-1">IP Address</p>
                <p className="text-white font-mono text-lg">{selectedProxy.ip}</p>
              </div>
              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <p className="text-xs text-white/40 uppercase tracking-wider font-bold mb-1">Port</p>
                <p className="text-white font-mono text-lg">{selectedProxy.port}</p>
              </div>
              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <p className="text-xs text-white/40 uppercase tracking-wider font-bold mb-1">Protocol</p>
                <p className="text-white font-mono text-lg uppercase">{selectedProxy.protocol}</p>
              </div>
              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <p className="text-xs text-white/40 uppercase tracking-wider font-bold mb-1">Speed</p>
                <p className="text-white font-mono text-lg">{selectedProxy.speed} Mbps</p>
              </div>
            </div>

            <div className="p-6 rounded-xl bg-gradient-to-br from-white/5 to-white/10 border border-white/10">
              <p className="text-xs text-white/40 uppercase tracking-wider font-bold mb-3">Location & ISP</p>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-white/60">Country</span>
                  <span className="text-white font-semibold">{selectedProxy.country}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/60">City</span>
                  <span className="text-white font-semibold">{selectedProxy.city}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/60">ISP</span>
                  <span className="text-white font-semibold">{selectedProxy.isp}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/60">Uptime</span>
                  <span className="text-green-400 font-semibold flex items-center gap-1">
                    <CheckCircle size={14} />
                    {selectedProxy.uptime}%
                  </span>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <p className="text-xs text-white/40 uppercase tracking-wider font-bold">Copy Formats</p>
              <button onClick={() => copyProxy(selectedProxy, 'url')} className="w-full p-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-all text-left group">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-semibold">Full URL</span>
                  <Copy size={16} className="text-white/40 group-hover:text-white transition-colors" />
                </div>
                <code className="text-xs text-white/60 font-mono break-all">{ProxyService.formatProxyUrl(selectedProxy)}</code>
              </button>
            </div>
          </div>
        </div>
      </div>;
  }

  return <div className="min-h-screen flex flex-col relative overflow-hidden bg-black">
      {/* Sidebar Menu */}
      {isMenuOpen && <div className="fixed inset-0 z-[100] flex animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-xl" onClick={() => setIsMenuOpen(false)} />
          <div className="relative w-72 h-full bg-[#0a0a0f] border-r border-white/10 p-6 flex flex-col animate-in slide-in-from-left duration-300">
            <div className="flex items-center justify-between mb-8 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
                  <ShieldCheck size={24} className="text-white" />
                </div>
                <div>
                  <h2 className="text-white font-black text-xl tracking-tighter uppercase italic leading-none">GHOST<span className="text-cyan-400">NET</span></h2>
                  <p className="text-[8px] text-white/40 font-black uppercase tracking-widest mt-1">Terminal v0.2.5</p>
                </div>
              </div>
              <button onClick={() => setIsMenuOpen(false)} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/40 transition-colors">
                <X size={18} />
              </button>
            </div>

            <div className="mb-6 p-4 rounded-xl bg-white/5 border border-white/10 shrink-0">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-7 h-7 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400">
                   <Users size={14} />
                </div>
                <p className="text-white font-bold text-sm truncate">{user?.nickname || 'Guest Operator'}</p>
              </div>
              <p className="text-[9px] text-white/30 font-mono truncate">{apiKey || 'No Active API'}</p>
            </div>

            {/* Scrollable Nav Area */}
            <div className="flex-1 overflow-y-auto pr-2 -mr-2 custom-scrollbar">
              <nav className="space-y-6">
                <div className="space-y-1">
                  <p className="px-4 text-[9px] text-white/30 font-black uppercase tracking-widest mb-2">Main Dashboard</p>
                  {[{
                  id: 'email',
                  label: 'Ghost Inbox',
                  icon: <Mail size={18} />,
                  active: activeTab === 'email'
                }, {
                  id: 'proxy',
                  label: 'Proxy Node',
                  icon: <Globe size={18} />,
                  active: activeTab === 'proxy'
                }, {
                  id: 'report',
                  label: 'Report Center',
                  icon: <Flag size={18} />,
                  active: activeTab === 'report'
                }].map(item => <button key={item.id} onClick={() => {
                  setActiveTab(item.id as any);
                  setIsMenuOpen(false);
                  vibrate(30);
                }} className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all border ${item.active ? 'bg-gradient-to-r from-cyan-500/15 to-transparent border-cyan-500/40 text-white shadow-lg shadow-cyan-500/5' : 'border-transparent text-white/40 hover:bg-white/5 hover:text-white/60'}`}>
                      <div className={`${item.active ? 'text-cyan-400 scale-110' : 'text-current'} transition-transform`}>{item.icon}</div>
                      <span className="font-black uppercase tracking-[0.1em] text-[10px]">{item.label}</span>
                      {item.active && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,192,220,0.8)] animate-pulse" />}
                    </button>)}
                </div>

                <div className="space-y-1">
                  <p className="px-4 text-[9px] text-white/30 font-black uppercase tracking-widest mb-2">Automation & Dev</p>
                  {[{
                  id: 'tiktok',
                  label: 'TikTok Lab',
                  icon: <Zap size={18} />,
                  active: activeTab === 'tiktok'
                }, {
                  id: 'api',
                  label: 'Proxy API Key',
                  icon: <Key size={18} />,
                  active: activeTab === 'api'
                  }, {
                  id: 'code',
                  label: 'Code Control',
                  icon: <Code size={18} />,
                  active: activeTab === 'code'
                }].map(item => <button key={item.id} onClick={() => {
                  setActiveTab(item.id as any);
                  setIsMenuOpen(false);
                  vibrate(30);
                }} className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all border ${item.active ? 'bg-gradient-to-r from-cyan-500/15 to-transparent border-cyan-500/40 text-white shadow-lg shadow-cyan-500/5' : 'border-transparent text-white/40 hover:bg-white/5 hover:text-white/60'}`}>
                      <div className={`${item.active ? 'text-cyan-400 scale-110' : 'text-current'} transition-transform`}>{item.icon}</div>
                      <span className="font-black uppercase tracking-[0.1em] text-[10px]">{item.label}</span>
                      {item.active && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,192,220,0.8)] animate-pulse" />}
                    </button>)}
                </div>
              </nav>

              <div className="mt-8 space-y-2 pt-6 border-t border-white/10 mb-6">
                <button onClick={onBack} className="w-full flex items-center gap-4 px-4 py-4 rounded-xl text-white/40 hover:bg-white/5 transition-all">
                  <UserCircle size={20} />
                  <span className="font-black uppercase tracking-widest text-[11px]">Switch Account</span>
                </button>
                <button onClick={onLogout} className="w-full flex items-center gap-4 px-4 py-4 rounded-xl text-red-400/60 hover:bg-red-500/10 hover:text-red-400 transition-all">
                  <Trash2 size={20} />
                  <span className="font-black uppercase tracking-widest text-[11px]">Terminate Session</span>
                </button>
              </div>
            </div>
          </div>
        </div>}

      {/* Header */}
      <div className="sticky top-0 z-10 backdrop-blur-xl bg-black/80 border-b border-white/10 px-4 py-4">
        <div className="flex items-center justify-between max-w-4xl mx-auto">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsMenuOpen(true)} className="p-3 rounded-2xl bg-white/5 border border-white/10 text-white/80 hover:bg-white/10 transition-all active:scale-95 shadow-lg">
              <div className="space-y-1.5">
                <div className="w-7 h-0.5 bg-current rounded-full" />
                <div className="w-7 h-0.5 bg-current rounded-full" />
                <div className="w-5 h-0.5 bg-current rounded-full" />
              </div>
            </button>
            <div>
                <h1 className="text-white font-black text-xl tracking-tight uppercase italic flex items-center gap-2">
                {activeTab === 'email' ? 'Ghost Inbox' : activeTab === 'proxy' ? 'Proxy Node' : activeTab === 'tiktok' ? 'TikTok Lab' : activeTab === 'report' ? 'Report Center' : 'Code Control'}
                <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse shadow-[0_0_8px_#22c55e]" />
              </h1>
              <p className="text-[10px] text-white/30 uppercase font-black tracking-widest">Secure Channel Active</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
             <div className="flex flex-col items-end">
               <p className="text-[10px] text-white/40 font-black uppercase tracking-tighter">Status</p>
               <p className="text-cyan-400 font-bold text-xs uppercase">ONLINE</p>
             </div>
             <div className="w-10 h-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center">
                <Globe size={18} className="text-white/40" />
             </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="max-w-4xl mx-auto p-4 space-y-6">
          {/* TOP BANNER AD */}
          <div className="mb-4">
            <AdPlaceholder label="Top Navigation Ad 728x90" height="h-20" />
          </div>
          
          {/* Active Address Card */}
          {activeTab === 'email' && email && <div className="p-6 rounded-3xl border border-white/10 bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-md relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity pointer-events-none">
                 <Mail size={120} />
              </div>
              <div className="relative z-10">
                <p className="text-xs text-white/40 uppercase tracking-widest font-black mb-1">Assigned Address</p>
                <div className="flex items-center justify-between gap-4">
                   <h2 className="text-2xl md:text-3xl font-mono text-white truncate">{email.address}</h2>
                   <div className="flex gap-2 shrink-0">
                      <button onClick={copyEmail} className="p-3 rounded-2xl bg-white/5 border border-white/10 text-white/60 hover:text-white transition-all active:scale-95">
                         <Copy size={20} />
                      </button>
                      <button onClick={handleRegenerate} className="p-3 rounded-2xl bg-white/5 border border-white/10 text-white/40 hover:text-white transition-all active:scale-95 group/regen">
                         <RefreshCw size={20} className="group-hover/regen:rotate-180 transition-transform duration-500" />
                      </button>
                   </div>
                </div>
                <div className="mt-6 flex items-center gap-4">
                   <div className="flex-1">
                      <CountdownTimer expiresAt={email.expiresAt} onExpire={onExpire} glowColor={primaryGlow} />
                   </div>
                   <div className="px-4 py-2 rounded-xl bg-green-500/10 border border-green-500/20 text-green-400 text-[10px] font-black uppercase tracking-widest">
                      Active Channel
                   </div>
                </div>
              </div>
            </div>}

          {/* AD BELOW ADDRESS CARD */}
          {activeTab === 'email' && (
            <div className="my-4">
               <AdPlaceholder label="Inbox Upper Banner Ad" height="h-24" />
            </div>
          )}

          {/* TikTok Automation Lab */}
          {activeTab === 'tiktok' && <div className="space-y-6">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="md:col-span-2 space-y-4">
                  <div className="p-8 rounded-3xl border border-white/10 bg-white/5 backdrop-blur-md">
                    <div className="flex items-center gap-4 mb-8">
                       <div className="w-14 h-14 rounded-2xl bg-purple-500/20 flex items-center justify-center text-purple-400 shadow-lg shadow-purple-500/10">
                          <Zap size={32} />
                       </div>
                       <div>
                          <h2 className="text-white font-black text-2xl uppercase italic leading-none">Account Creator</h2>
                          <p className="text-white/40 text-xs font-bold uppercase tracking-widest mt-1">TikTok Automation Lab</p>
                       </div>
                    </div>

                    <div className="space-y-6">
                       <div>
                          <label className="block text-[10px] text-white/40 font-black uppercase tracking-widest mb-3">Target Platform</label>
                          <div className="flex gap-2">
                             <button className="flex-1 py-4 rounded-2xl bg-white/10 border border-white/20 text-white font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3">
                                <span>🎵</span> TikTok
                             </button>
                             <button className="flex-1 py-4 rounded-2xl bg-white/5 border border-white/5 text-white/20 font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 cursor-not-allowed">
                                <span>📸</span> Instagram
                             </button>
                          </div>
                       </div>

                       <div className="grid grid-cols-2 gap-4">
                          <div>
                             <label className="block text-[10px] text-white/40 font-black uppercase tracking-widest mb-3">Instance Count</label>
                             <div className="flex items-center gap-4 bg-black/40 p-4 rounded-2xl border border-white/10">
                                <button onClick={() => setAccountCount(Math.max(1, accountCount - 1))} className="text-white/40 hover:text-white transition-colors">-</button>
                                <span className="flex-1 text-center text-white font-black text-lg">{accountCount}</span>
                                <button onClick={() => setAccountCount(Math.min(50, accountCount + 1))} className="text-white/40 hover:text-white transition-colors">+</button>
                             </div>
                          </div>
                          <div>
                             <label className="block text-[10px] text-white/40 font-black uppercase tracking-widest mb-3">Target Handle</label>
                             <div className="relative">
                                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40 font-bold">@</span>
                                <input type="text" value={targetUsername} onChange={e => setTargetUsername(e.target.value)} placeholder="username" className="w-full pl-10 pr-4 py-4 rounded-2xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-cyan-500/50 transition-colors" />
                             </div>
                          </div>
                       </div>

                       <button onClick={runTikTokAutomation} disabled={tikTokStep !== 'idle' && tikTokStep !== 'success' && tikTokStep !== 'failed'} className="w-full py-5 rounded-2xl font-black text-white text-lg transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 shadow-xl shadow-cyan-500/20" style={{
                    background: `linear-gradient(135deg, ${primaryGlow}, ${accentGlow})`
                  }}>
                         {tikTokStep === 'idle' ? 'START AUTOMATION CYCLE' : tikTokStep === 'success' ? 'RUN NEW CYCLE' : 'LAB IN PROGRESS...'}
                       </button>
                    </div>
                  </div>

                  {/* Smart Helper */}
                  {showHelper && <div className="p-6 rounded-3xl border border-cyan-500/30 bg-cyan-500/5 backdrop-blur-md animate-in fade-in slide-in-from-top-4 duration-500">
                       <div className="flex items-start gap-4">
                          <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 shrink-0">
                             <Info size={20} />
                          </div>
                          <div className="flex-1">
                             <div className="flex items-center justify-between mb-1">
                                <h3 className="text-cyan-400 font-black text-sm uppercase tracking-widest">Smart Helper</h3>
                                <button onClick={() => setShowHelper(false)} className="text-white/20 hover:text-white transition-colors"><X size={16} /></button>
                             </div>
                             <p className="text-white/70 text-sm leading-relaxed italic">
                               {SMART_HELPER_MESSAGES[tikTokStep]}
                             </p>
                          </div>
                       </div>
                    </div>}
                </div>

                <div className="space-y-4">
                  <div className="p-6 rounded-3xl border border-white/10 bg-white/5">
                     <h3 className="text-white font-black text-xs uppercase tracking-widest mb-4">Live Timeline</h3>
                     <div className="space-y-4">
                        {[{
                    step: 'creating',
                    label: 'Account Creation',
                    icon: <UserPlus size={16} />
                  }, {
                    step: 'setup_profile',
                    label: 'Profile Setup',
                    icon: <Users size={16} />
                  }, {
                    step: 'setup_bio',
                    label: 'Bio Optimization',
                    icon: <Smartphone size={16} />
                  }, {
                    step: 'following',
                    label: 'Follow Engagement',
                    icon: <Star size={16} />
                  }, {
                    step: 'growth',
                    label: 'Growth Guardrails',
                    icon: <Zap size={16} />
                  }].map((s, i) => {
                    const isActive = tikTokStep === s.step;
                    const isDone = ['creating', 'setup_profile', 'setup_bio', 'following', 'growth', 'success'].indexOf(tikTokStep) > i;
                    return <div key={s.step} className={`flex items-center gap-3 transition-opacity ${isActive || isDone ? 'opacity-100' : 'opacity-20'}`}>
                               <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isDone ? 'bg-green-500/20 text-green-400' : isActive ? 'bg-cyan-500/20 text-cyan-400 animate-pulse' : 'bg-white/5 text-white/40'}`}>
                                  {isDone ? <CheckCircle size={16} /> : s.icon}
                               </div>
                               <span className={`text-[10px] font-black uppercase tracking-widest ${isActive ? 'text-white' : 'text-white/40'}`}>{s.label}</span>
                            </div>;
                  })}
                     </div>
                  </div>

                  <div className="p-6 rounded-3xl border border-white/10 bg-white/5 text-center">
                     <p className="text-[10px] text-white/40 font-black uppercase mb-2">Total Managed Accounts</p>
                     <p className="text-3xl font-black text-white">{tikTokAccounts.length}</p>
                     <p className="text-[10px] text-cyan-400 font-bold uppercase mt-1 tracking-tighter">Encrypted & Stored</p>
                  </div>
                </div>
              </div>

              {/* Accounts Grid */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {tikTokAccounts.map((account, idx) => <div key={idx} className="p-5 rounded-3xl border border-white/10 bg-black/40 hover:bg-black/60 transition-all group">
                    <div className="flex items-center justify-between mb-4">
                       <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center font-black text-white/20">
                             {idx + 1}
                          </div>
                          <div>
                             <p className="text-white font-bold truncate max-w-[120px]">@{account.username}</p>
                             <div className="flex items-center gap-1">
                                <Users size={10} className="text-white/40" />
                                <span className="text-[10px] text-white/40 font-bold">{account.followers} Followers</span>
                             </div>
                          </div>
                       </div>
                       {account.lastCode && <div className="px-2 py-1 rounded bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 text-[9px] font-black">
                            {account.lastCode}
                         </div>}
                    </div>
                    
                    <div className="space-y-2 mb-4">
                       <div className="flex items-center justify-between text-[10px]">
                          <span className="text-white/40 font-bold">Password</span>
                          <span className="text-white font-mono">{account.password}</span>
                       </div>
                       <div className="flex items-center justify-between text-[10px]">
                          <span className="text-white/40 font-bold">Status</span>
                          <span className={`font-black uppercase tracking-widest ${account.followers >= 50 ? 'text-green-400' : 'text-cyan-400 animate-pulse'}`}>
                             {account.followers >= 50 ? 'Verified' : 'Growing...'}
                          </span>
                       </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 mb-2">
                       <button onClick={() => {
                  navigator.clipboard.writeText(`User: ${account.username}\nPass: ${account.password}`);
                  showToast('Credentials copied!', 'success');
                }} className="py-2 rounded-xl bg-white/5 border border-white/10 text-white/40 text-[9px] font-black uppercase hover:bg-white/10 transition-colors">
                          Copy Pass
                       </button>
                       <button onClick={() => {
                  navigator.clipboard.writeText(account.lastCode || '');
                  showToast('Verification code copied!', 'success');
                }} className="py-2 rounded-xl bg-white/5 border border-white/10 text-white/40 text-[9px] font-black uppercase hover:bg-white/10 transition-colors">
                          Copy Code
                       </button>
                    </div>

                    <div className="pt-3 border-t border-white/5 grid grid-cols-5 gap-1">
                       {[{
                  icon: '👁️',
                  label: 'View'
                }, {
                  icon: '❤️',
                  label: 'Like'
                }, {
                  icon: '💬',
                  label: 'Comment'
                }, {
                  icon: '🔁',
                  label: 'Repost'
                }, {
                  icon: '📤',
                  label: 'Share'
                }].map(action => <button key={action.label} onClick={() => showToast(`${action.label} automation queued...`, 'info')} className="flex flex-col items-center gap-1 p-2 rounded-xl hover:bg-white/5 transition-colors group/action">
                            <span className="text-sm group-hover/action:scale-110 transition-transform">{action.icon}</span>
                            <span className="text-[7px] text-white/20 font-black uppercase">{action.label}</span>
                         </button>)}
                    </div>
                  </div>)}
              </div>
            </div>}

          {/* Proxy Tab Content */}
          {activeTab === 'proxy' && <div className="space-y-6">
              <div className="p-8 rounded-3xl border border-white/10 bg-white/5 backdrop-blur-md">
                 <div className="flex items-center gap-4 mb-8">
                    <div className="w-14 h-14 rounded-2xl bg-green-500/20 flex items-center justify-center text-green-400 shadow-lg shadow-green-500/10">
                       <Globe size={32} />
                    </div>
                    <div>
                       <h2 className="text-white font-black text-2xl uppercase italic leading-none">Residential Proxy</h2>
                       <p className="text-white/40 text-xs font-bold uppercase tracking-widest mt-1">Network Infrastructure</p>
                    </div>
                 </div>

                 <div className="space-y-6">
                    <div>
                       <div className="flex items-center justify-between mb-3">
                          <label className="text-[10px] text-white/40 font-black uppercase tracking-widest">Generation Quantity</label>
                          <span className="text-cyan-400 font-black">{proxyCountToGenerate}</span>
                       </div>
                       <input type="range" min="1" max="50" value={proxyCountToGenerate} onChange={e => setProxyCountToGenerate(Number(e.target.value))} className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-cyan-500" />
                       <div className="flex justify-between mt-2">
                          <span className="text-[10px] text-white/20 font-black">01</span>
                          <span className="text-[10px] text-white/20 font-black">50</span>
                       </div>
                    </div>

                    <button onClick={generateMoreProxies} disabled={loading} className="w-full py-5 rounded-2xl font-black text-white text-lg transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50" style={{
                background: `linear-gradient(135deg, #00d9ff, #0080ff)`
              }}>
                      {loading ? 'DEPLOYING NODES...' : `GENERATE ${proxyCountToGenerate} NODES`}
                    </button>
                 </div>
              </div>

              <div className="space-y-4">
                 <div className="flex items-center justify-between px-2">
                    <h3 className="text-white font-black text-xs uppercase tracking-widest">Active Node Pool ({proxies.length})</h3>
                    <button onClick={exportAllProxies} className="text-cyan-400 font-bold text-[10px] uppercase tracking-widest flex items-center gap-2">
                       <FileDown size={14} /> Export All
                    </button>
                 </div>
                 
                 <div className="grid md:grid-cols-2 gap-4">
                    {proxies.map(proxy => <div key={proxy.id} onClick={() => setSelectedProxy(proxy)} className="p-5 rounded-3xl border border-white/10 bg-black/40 hover:bg-black/60 transition-all cursor-pointer group">
                        <div className="flex items-center justify-between mb-4">
                           <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white/40">
                                 <Globe size={18} />
                              </div>
                              <div>
                                 <p className="text-white font-mono font-bold">{proxy.ip}:{proxy.port}</p>
                                 <p className="text-[10px] text-white/40 uppercase font-black">{proxy.isp}</p>
                              </div>
                           </div>
                           <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-green-500/10 border border-green-500/20 text-green-400 text-[9px] font-black uppercase">
                              <div className="w-1 h-1 rounded-full bg-current animate-pulse" />
                              {proxy.uptime}%
                           </div>
                        </div>
                        <div className="flex items-center justify-between mt-2">
                           <p className="text-[10px] text-white/30 uppercase font-black">{proxy.city}, {proxy.country}</p>
                           <ArrowLeft size={14} className="rotate-180 text-white/20 group-hover:text-cyan-400 transition-colors" />
                        </div>
                      </div>)}
                 </div>
              </div>
            </div>}

          {/* Email Tab Content */}
          {activeTab === 'email' && <div className="space-y-4">
              <div className="flex items-center gap-4 px-2">
                 <div className="flex-1 relative">
                    <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" />
                    <input type="text" placeholder="Search encrypted packets..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full pl-10 pr-4 py-4 rounded-2xl bg-white/5 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:border-cyan-500/50 transition-all" />
                 </div>
                 <button onClick={refreshInbox} disabled={loading} className="p-4 rounded-2xl bg-white/5 border border-white/10 text-[#a1a1aa] hover:text-white transition-all disabled:opacity-50">
                   <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
                 </button>
              </div>

              {filteredMessages.length === 0 ? <div className="py-20 text-center space-y-4">
                   <div className="w-20 h-20 rounded-full bg-white/5 border border-white/5 flex items-center justify-center mx-auto opacity-20">
                      <Mail size={40} className="text-white" />
                   </div>
                   <div>
                      <h3 className="text-white font-black text-xl uppercase italic">No Signals Detected</h3>
                      <p className="text-white/30 text-xs font-bold uppercase tracking-widest">Waiting for incoming data stream</p>
                   </div>
                </div> : <div className="space-y-3">
                  {filteredMessages.map((msg, index) => (
                    <div key={msg.id} className="space-y-3">
                      <div onClick={() => openMessage(msg)} className="p-5 rounded-3xl border border-white/10 bg-white/5 hover:bg-white/10 transition-all cursor-pointer group relative overflow-hidden">
                        {!msg.isRead && <div className="absolute top-0 left-0 w-1 h-full bg-cyan-400" />}
                        <div className="flex items-start justify-between mb-2">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                  {msg.isFavorite && <Star size={14} className="fill-yellow-400 text-yellow-400" />}
                                  <h4 className={`font-bold text-lg truncate ${msg.isRead ? 'text-white/60' : 'text-white'}`}>
                                    {enableEmoji ? `📧 ${msg.subject}` : msg.subject}
                                  </h4>
                              </div>
                              <p className="text-xs text-white/40 font-mono truncate">{msg.from.address}</p>
                            </div>
                            <div className="flex items-center gap-3 shrink-0 ml-4">
                              {msg.hasAttachments && <Paperclip size={14} className="text-white/40" />}
                              <p className="text-[10px] text-white/20 font-black uppercase">{new Date(msg.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}</p>
                            </div>
                        </div>
                        <p className="text-sm text-white/40 line-clamp-1 leading-relaxed">{msg.intro}</p>
                      </div>
                      
                      {/* IN-LIST AD (every 3 messages) */}
                      {(index + 1) % 3 === 0 && (
                        <div className="py-1">
                          <AdPlaceholder label="In-List Native Ad Unit" height="h-28" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>}
            </div>}

          {/* AD AT THE BOTTOM OF DASHBOARD */}
          <div className="mt-8">
            <AdPlaceholder label="Footer Segment Dashboard Ad" height="h-32" />
          </div>

          {/* API Key Tab Content - Integrated Documentation */}
          {activeTab === 'api' && <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
               <ApiDocsPage onBack={() => setActiveTab('email')} primaryGlow={primaryGlow} accentGlow={accentGlow} />
            </div>}

          {/* Report Center Tab Content */}
          {activeTab === 'report' && <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
               <ReportPage onBack={() => setActiveTab('email')} primaryGlow={primaryGlow} accentGlow={accentGlow} soundEnabled={soundEnabled} apiKey={apiKey} />
            </div>}

          {/* Code Control Center Tab Content */}
          {activeTab === 'code' && <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
               <CodeControlCenter primaryGlow={primaryGlow} accentGlow={accentGlow} soundEnabled={soundEnabled} />
            </div>}
        </div>
      </div>

      {/* Interstitial Ad Mockup */}
      {showInterstitial && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-black animate-in fade-in duration-500">
          <div className="relative w-full max-w-lg aspect-square rounded-3xl border border-white/20 bg-[#0a0a0f] p-8 flex flex-col items-center justify-center text-center shadow-2xl overflow-hidden">
            <div className="absolute top-4 right-4">
              <button onClick={confirmRegenerate} className="flex items-center gap-2 p-2 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-white/60 font-bold text-xs uppercase tracking-widest transition-all">
                Close <X size={16} />
              </button>
            </div>
            
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center mb-6 shadow-2xl">
              <Zap size={40} className="text-white" />
            </div>
            
            <h2 className="text-3xl font-black text-white mb-4 italic uppercase">Sponsor Message</h2>
            <p className="text-white/40 text-sm mb-8 leading-relaxed max-w-xs">
              This space is reserved for a high-impact Interstitial Ad. It triggers before critical user actions like address regeneration.
            </p>
            
            <div className="w-full h-32 rounded-2xl border border-white/5 bg-white/5 flex items-center justify-center">
              <p className="text-[10px] font-black uppercase tracking-[0.5em] text-white/20 italic">Visual Ad Content</p>
            </div>

            <button onClick={confirmRegenerate} className="mt-8 text-cyan-400 font-black text-xs uppercase tracking-[0.3em] hover:text-white transition-colors">
              Continue to New Identity
            </button>
          </div>
        </div>
      )}

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>;
};

export default InboxPage;