import { Copy, CheckCircle2, Zap, Shield, Clock, Key, RefreshCw, Code, Info } from 'lucide-react';
import { useState, useEffect } from 'react';
import { storage } from '@/utils/storage';

interface ApiDocsPageProps {
  onBack: () => void;
  primaryGlow: string;
  accentGlow: string;
}

const API_BASE = 'http://localhost:3000';

const ApiDocsPage = ({ primaryGlow, accentGlow }: ApiDocsPageProps) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [apiKey, setApiKey] = useState('');

  useEffect(() => {
    const saved = storage.getApiKey();
    if (saved) setApiKey(saved);
  }, []);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  // 🔥 API KEY من السيرفر الحقيقي
  const generateApiKey = async () => {
    const res = await fetch(`${API_BASE}/api/keys/generate`, {
      method: 'POST'
    });

    const data = await res.json();
    setApiKey(data.apiKey);
    storage.saveApiKey(data.apiKey);
  };

  // 🔥 طلب API حقيقي
  const apiRequest = async (path: string, body?: any) => {
    const res = await fetch(`${API_BASE}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': apiKey
      },
      body: body ? JSON.stringify(body) : undefined
    });

    return res.json();
  };

  const testVerify = async () => {
    const res = await apiRequest('/api/v1/accounts/verify', {
      platform: 'tiktok',
      username: 'demo_user'
    });

    console.log(res);
  };

  const endpoints = [
    {
      id: 'auth',
      method: 'POST',
      path: '/api/v1/accounts/verify',
      description: 'Verify account',
      example: `{
  "platform": "tiktok",
  "username": "demo_user"
}`
    },
    {
      id: 'automation',
      method: 'POST',
      path: '/api/v1/automation/setup',
      description: 'Start automation',
      example: `{
  "account_id": "acc_123",
  "action": "growth"
}`
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white p-6">
      
      {/* HEADER */}
      <div className="mb-10">
        <h1 className="text-3xl font-black flex items-center gap-3">
          <Key style={{ color: primaryGlow }} />
          API Docs (LIVE)
        </h1>
        <p className="text-white/40">Connected to backend server</p>
      </div>

      {/* API KEY */}
      <div className="p-6 bg-black/40 border border-white/10 rounded-2xl mb-10">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-white/50 text-sm mb-2">API KEY</p>
            <code className="text-cyan-300">
              {apiKey || 'No key generated'}
            </code>
          </div>

          <button
            onClick={generateApiKey}
            className="px-4 py-2 bg-white/10 rounded-xl hover:bg-white/20"
          >
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {/* ENDPOINTS */}
      <div className="space-y-6">
        {endpoints.map((ep) => (
          <div key={ep.id} className="p-6 bg-black/40 border border-white/10 rounded-2xl">
            
            <div className="flex justify-between mb-4">
              <span className="text-cyan-400 font-bold">{ep.method}</span>
              <code className="text-white/60">{ep.path}</code>
            </div>

            <p className="text-white/40 mb-4">{ep.description}</p>

            <pre className="bg-black p-4 rounded-xl text-xs text-white/70 overflow-auto">
              {ep.example}
            </pre>

            <button
              onClick={testVerify}
              className="mt-4 px-4 py-2 bg-cyan-500/20 text-cyan-300 rounded-xl"
            >
              Test Endpoint
            </button>
          </div>
        ))}
      </div>

    </div>
  );
};

export default ApiDocsPage;