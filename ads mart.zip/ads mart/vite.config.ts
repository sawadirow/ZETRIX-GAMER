import { defineConfig } from "vite";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { viteSingleFile } from "vite-plugin-singlefile";
import { aippyTaggerPlugin, aippyPreloadPlugin, assetConstantsPlugin } from "@aippy/vite-plugins";

export default defineConfig(({ mode }) => ({
  server: { host: "::", port: 8080 },
  plugins: [
    react(),
    tailwindcss(),
    mode === "development" && assetConstantsPlugin({ extensions: [".png", ".jpg", ".jpeg", ".gif", ".svg", ".mp4", ".mp3", ".wav", ".ogg", ".webm"], srcDir: "src", outputFile: "src/config/assets.json", devMode: true }),
    mode === "development" && aippyTaggerPlugin(),
    viteSingleFile({ useRecommendedBuildConfig: true, removeViteModuleLoader: true, deleteInlinedFiles: true }),
    aippyPreloadPlugin({ extensions: [".png", ".jpg", ".jpeg", ".gif", ".svg", ".woff", ".woff2", ".ttf", ".eot", ".mp4", ".mp3", ".wav", ".ogg", ".webm", ".task", ".tflite"], srcDir: "src", outDir: "dist", deepScan: true })
  ].filter(Boolean),
  resolve: { alias: { "@": path.resolve(import.meta.dirname, "./src") } },
  build: { sourcemap: mode === "development", minify: mode === "production" ? "esbuild" : false },
}));