import type { TempEmail, EmailMessage, MailTmAccount, MailTmMessage, MailTmMessageDetail } from '@/types/email';

const API_BASE = 'https://api.mail.tm';

export class MailService {
  private static async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    let response: Response;

    try {
      response = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options?.headers,
        },
      });
    } catch {
      throw new Error('Network connection failed. Please check your internet and try again.');
    }

    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: '' }));
      throw new Error(error.message || `HTTP ${response.status}`);
    }

    if (response.status === 204) {
      return undefined as T;
    }

    return response.json();
  }

  static async getDomains(): Promise<string[]> {
    try {
      const data = await this.request<{ 'hydra:member'?: Array<{ domain: string }> }>('/domains');
      if (!data || !Array.isArray(data['hydra:member'])) {
        return ['1secmail.com', '1secmail.org', '1secmail.net'];
      }

      const domains = data['hydra:member']
        .map(item => item.domain)
        .filter((domain): domain is string => Boolean(domain));

      return domains.length > 0 ? domains : ['1secmail.com', '1secmail.org', '1secmail.net'];
    } catch {
      return ['1secmail.com', '1secmail.org', '1secmail.net'];
    }
  }

  static async createAccount(address: string, password: string): Promise<MailTmAccount> {
    return this.request<MailTmAccount>('/accounts', {
      method: 'POST',
      body: JSON.stringify({ address, password }),
    });
  }

  static async getToken(address: string, password: string): Promise<string> {
    const data = await this.request<{ token: string }>('/token', {
      method: 'POST',
      body: JSON.stringify({ address, password }),
    });
    return data.token;
  }

  static async getMessages(token: string): Promise<EmailMessage[]> {
    try {
      const data = await this.request<{ 'hydra:member'?: MailTmMessage[] }>('/messages', {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!data || !Array.isArray(data['hydra:member'])) {
        return [];
      }

      return data['hydra:member'].map(msg => ({
        id: msg.id,
        from: msg.from,
        to: msg.to,
        subject: msg.subject || '(No Subject)',
        intro: msg.intro || '',
        text: '',
        html: [],
        hasAttachments: msg.hasAttachments,
        attachments: [],
        size: msg.size,
        createdAt: msg.createdAt,
        updatedAt: msg.updatedAt,
        isRead: msg.seen,
        isFavorite: false,
      }));
    } catch {
      return [];
    }
  }

  static async getMessage(token: string, messageId: string): Promise<EmailMessage | null> {
    try {
      const msg = await this.request<MailTmMessageDetail>(`/messages/${messageId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      return {
        id: msg.id,
        from: msg.from,
        to: msg.to,
        subject: msg.subject || '(No Subject)',
        intro: msg.intro || '',
        text: msg.text || '',
        html: msg.html || [],
        hasAttachments: msg.hasAttachments,
        attachments: msg.attachments || [],
        size: msg.size,
        createdAt: msg.createdAt,
        updatedAt: msg.updatedAt,
        isRead: msg.seen,
        isFavorite: false,
      };
    } catch {
      return null;
    }
  }

  static async markAsRead(token: string, messageId: string): Promise<void> {
    try {
      await this.request(`/messages/${messageId}`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}` },
        body: JSON.stringify({ seen: true }),
      });
    } catch {
      // Ignore errors
    }
  }

  static async deleteMessage(token: string, messageId: string): Promise<void> {
    await this.request(`/messages/${messageId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
  }

  static generateRandomUsername(): string {
    const adjectives = ['cyber', 'neon', 'ghost', 'shadow', 'quantum', 'digital', 'phantom', 'void', 'nexus', 'matrix'];
    const nouns = ['wolf', 'hawk', 'viper', 'raven', 'tiger', 'dragon', 'phoenix', 'storm', 'blade', 'pulse'];
    const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const noun = nouns[Math.floor(Math.random() * nouns.length)];
    const num = Math.floor(Math.random() * 999);
    return `${adj}${noun}${num}`;
  }

  static async createTempEmail(username?: string, domain?: string): Promise<TempEmail> {
    const domains = await this.getDomains();
    const selectedDomain = domain || domains[0];
    const password = Math.random().toString(36).slice(-12) + Math.random().toString(36).slice(-12);
    const maxAttempts = 5;

    for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
      const selectedUsername = attempt === 0 && username
        ? username
        : `${this.generateRandomUsername()}${Math.floor(Math.random() * 1000)}`;
      const address = `${selectedUsername}@${selectedDomain}`;

      try {
        const account = await this.createAccount(address, password);
        const token = await this.getToken(address, password);
        const now = Date.now();

        return {
          address,
          username: selectedUsername,
          domain: selectedDomain,
          createdAt: now,
          expiresAt: now + 60 * 60 * 1000,
          token,
          accountId: account.id,
        };
      } catch (error) {
        if (error instanceof Error && error.message.toLowerCase().includes('used')) {
          continue;
        }
        throw error;
      }
    }

    throw new Error('Could not create a new temporary email right now. Please try again.');
  }
}